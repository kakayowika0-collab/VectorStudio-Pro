/* ------------------------------------------------------------------
   STEP: paste your two Supabase values between the quotes below.
   Supabase dashboard > Project Settings > API
     - Project URL        (looks like https://abcdxyz.supabase.co)
     - Publishable key    (or "anon public" key). NEVER use the secret / service_role key.
   ------------------------------------------------------------------ */
window.VS_SUPABASE = {
  url:     "https://hvmwfiemgwkltrnydtrc.supabase.co/rest/v1/",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh2bXdmaWVtZ3drbHRybnlkdHJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI2NTY1MDUsImV4cCI6MjEwODIzMjUwNX0.DGeuarvxT6rsWOslnXApw-F-thA7y-uc3nJzhxrH9sU"
};
