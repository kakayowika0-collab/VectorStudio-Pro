/* VectorStudio Pro - service worker (this is what makes offline mode work)
   After you change ANY file and re-upload, also change the number below
   (v1 -> v2 -> v3 ...) so everybody's phone downloads the new files. */
const VERSION = 'v1';
const SHELL = 'vsp-shell-' + VERSION;
const RUNTIME = 'vsp-runtime-' + VERSION;
const CORE = [
  './', 'index.html', 'manifest.json', 'supabase.min.js', 'supabase-config.js', 'legal.html',
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-512.png', 'icons/apple-touch-icon.png', 'icons/favicon.png',
  'img/logo.png', 'img/bg1.jpg', 'img/bg2.jpg', 'img/bg3.jpg', 'img/bg4.jpg'
];

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const cache = await caches.open(SHELL);
    await Promise.allSettled(CORE.map((u) => cache.add(new Request(u, { cache: 'reload' }))));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keep = [SHELL, RUNTIME];
    for (const k of await caches.keys()) if (k.startsWith('vsp-') && !keep.includes(k)) await caches.delete(k);
    await self.clients.claim();
  })());
});

function timeout(ms) { return new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms)); }

async function networkFirst(req, key) {
  const cache = await caches.open(SHELL);
  const net = fetch(req).then((res) => {
    if (res && res.ok && res.type === 'basic') cache.put(key || req, res.clone());
    return res;
  });
  try {
    return await Promise.race([net, timeout(3500)]);
  } catch (_) {
    const hit = (await cache.match(key || req, { ignoreSearch: true })) || (key && (await cache.match('./')));
    if (hit) return hit;
    try { return await net; } catch (__) { return new Response('You are offline.', { status: 503 }); }
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(SHELL);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && res.ok) cache.put(req, res.clone());
  return res;
}

async function staleWhileRevalidate(req) {
  const cache = await caches.open(RUNTIME);
  const hit = await cache.match(req);
  const net = fetch(req).then((res) => {
    if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
    return res;
  }).catch(() => null);
  return hit || (await net) || new Response('', { status: 504 });
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  if (/(^|\.)supabase\.(co|in|com)$/.test(url.hostname)) return;   // never cache login / database / storage calls
  if (url.origin === self.location.origin) {
    if (req.mode === 'navigate') return e.respondWith(networkFirst(req, 'index.html'));
    if (/\.(png|jpe?g|webp|gif|svg|ico|woff2?)$/i.test(url.pathname)) return e.respondWith(cacheFirst(req));
    return e.respondWith(networkFirst(req));
  }
  e.respondWith(staleWhileRevalidate(req));   // fonts + icons from other websites
});

/* The page asks us to save the font / icon style sheets so they work offline too */
async function precacheCss(cssUrl) {
  const cache = await caches.open(RUNTIME);
  const res = await fetch(cssUrl, { mode: 'cors' });
  if (!res.ok) return;
  cache.put(cssUrl, res.clone());
  const text = await res.text();
  const files = new Set();
  if (cssUrl.includes('fonts.googleapis.com')) {
    const re = /\/\*\s*([\w-]+)\s*\*\/\s*@font-face\s*\{[^}]*?url\((https:[^)]+)\)/g;
    let m;
    while ((m = re.exec(text))) if (m[1] === 'latin') files.add(m[2]);
  } else {
    const re = /url\(([^)]+)\)/g;
    let m;
    while ((m = re.exec(text))) {
      const u = m[1].replace(/['"]/g, '').trim();
      if (/\.woff2(\?|#|$)/.test(u)) files.add(new URL(u, cssUrl).href);
    }
  }
  const list = [...files];
  for (let i = 0; i < list.length; i += 6) {
    await Promise.allSettled(list.slice(i, i + 6).map(async (f) => {
      if (await cache.match(f)) return;
      const r = await fetch(f, { mode: 'cors' });
      if (r.ok) await cache.put(f, r);
    }));
  }
}
self.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CACHE_URLS' && Array.isArray(e.data.urls)) {
    e.waitUntil(Promise.allSettled(e.data.urls.map(precacheCss)));
  }
});
