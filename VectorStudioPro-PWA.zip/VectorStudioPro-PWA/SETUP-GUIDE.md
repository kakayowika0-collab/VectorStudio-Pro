# VectorStudio Pro – Setup Guide (simple steps)

Do the steps in order. Total time: about 20 minutes.

## What is inside the zip
- index.html – your app, now with login, cloud saving, admin and offline mode
- manifest.json – the app's identity file (name, icon, colours)
- sw.js – the service worker (makes the app work offline)
- supabase-config.js – the ONE file where you paste your Supabase keys
- supabase.min.js – Supabase tools (already included, don't touch)
- legal.html – your Terms & Privacy text (edit the [brackets])
- supabase_setup.sql – the database setup code
- icons/ and img/ – app icons, your logo and the 4 login pictures

---

## PART 1 – Create your Supabase project
1. Go to **supabase.com** and sign in (or create an account).
2. Tap **New project**. Give it the name **VectorStudio Pro**.
3. Create a **Database password** and save it somewhere safe.
4. Choose the **Region** nearest to your users, then tap **Create new project**. Wait 1–2 minutes.

## PART 2 – Run the setup code (this builds everything)
1. In your project, open **SQL Editor** (left menu) → **New query**.
2. Open the file **supabase_setup.sql**, copy ALL the text and paste it into the editor.
3. Tap **Run**. You should see "Success. No rows returned".
   - This creates: user profiles, private storage for projects, visit/time tracking, and the hidden admin panel for **kakayowika0@gmail.com**.
   - You can run it again later – it will not delete anything.

## PART 3 – Login settings
1. Go to **Authentication → Sign In / Providers**. Make sure **Email** is ON.
2. Keep **Confirm email** ON (this protects your admin account).
3. Set **Minimum password length** to **8**.
4. For real users, set up your own email sender: **Authentication → Emails → SMTP Settings** (Resend or Brevo both have free plans). Supabase's built-in sender only allows a few emails per hour, so many new users will get blocked without this.

## PART 4 – Connect the app to Supabase
1. In Supabase go to **Project Settings → API** (or **API Keys**).
2. Copy the **Project URL** and the **Publishable key** (or "anon public" key).
   - NEVER use the "secret" or "service_role" key.
3. Open **supabase-config.js** and paste them between the quotes. Save.

## PART 5 – Put the app online (needs HTTPS for offline mode)
Pick one:
- **Netlify Drop**: go to app.netlify.com/drop and drag the whole unzipped folder in. You get a link right away.
- **Cloudflare Pages** → Create project → Direct Upload → upload the folder.
- **GitHub Pages** → upload all files to a repository and turn on Pages.

Then copy your new website link and go back to Supabase:
**Authentication → URL Configuration** → set **Site URL** to your link, and add the same link under **Redirect URLs**. (Without this, the email confirm link will not bring users back to your app.)

## PART 6 – Make yourself the admin
1. Open your app link. Tap **Sign up** and use **kakayowika0@gmail.com**. Do this FIRST, before sharing the link with anyone.
2. Tick the Terms box, create the account, then open the confirmation email and tap the link.
3. Log in. Tap the small round **K** button at the bottom-left. You will see **Admin panel**.
4. No other user will ever see that button or the admin code. The database only gives it to this confirmed email.

In the admin panel you can see: total users, new users, active users, users who have not come back (7 and 30 days), time spent in the app, visits, emails, projects, storage, a 14-day chart, each user's recent sessions, and export everything to CSV.

## PART 7 – Install on a phone and test offline
1. Open your link on the phone while online.
2. **Android (Chrome)**: menu ⋮ → **Install app**. **iPhone (Safari)**: Share → **Add to Home Screen**.
3. Open the app once while online (so it saves its files), then turn on airplane mode and open it again. It should still work.
4. Test cloud saving: save a project (**Projects tab → Save**), then log in on another phone. Your project appears there.

---

## Things to know
- **Cloud saving covers projects saved in the Projects tab.** Quick auto-save and recovery stay on the device.
- Offline work syncs to the cloud automatically when the internet returns.
- Signing out removes projects from that device (they stay safe in the cloud and come back when you log in).
- Time used = time the app is open on screen. Offline time is counted and uploaded later.
- iPhone: the installed app and Safari keep separate logins. Users log in once inside the installed app.

## Update your Terms (important)
Open **legal.html** and replace every [Insert …] bracket (your name, email, address, dates). I added a short section "3A. Accounts, Cloud Sync & Usage Information" because the app now stores emails and usage. Ask a Nigerian lawyer to review before launch.

## When you change any file later
Re-upload the files, and also open **sw.js** and change `const VERSION = 'v1';` to `'v2'` (then v3, v4…). That tells every phone to download the new files.

## If something does not work
- "Setup needed" on the login screen → supabase-config.js still has the placeholder text.
- "Could not load data" in admin → run the full SQL again (Part 2).
- No Admin panel button → confirm the email first, and log in with kakayowika0@gmail.com exactly.
- Confirmation email not arriving → check spam, then set up SMTP (Part 3, step 4).
