-- =====================================================================
--  VectorStudio Pro  -  Supabase setup  (run this ONCE)
--  Supabase dashboard > SQL Editor > New query > paste all > Run
--  Safe to run again: it will not delete any data.
-- =====================================================================

-- ---------- 1. TABLES ------------------------------------------------
create table if not exists public.profiles (
  id                uuid primary key references auth.users(id) on delete cascade,
  email             text not null,
  created_at        timestamptz not null default now(),
  last_seen_at      timestamptz,
  visit_count       integer not null default 0,
  total_seconds     bigint  not null default 0,
  terms_version     text,
  terms_accepted_at timestamptz
);

create table if not exists public.app_sessions (
  id               uuid primary key,
  user_id          uuid not null references auth.users(id) on delete cascade,
  started_at       timestamptz not null default now(),
  last_ping        timestamptz not null default now(),
  duration_seconds integer not null default 0,
  device           text
);
create index if not exists app_sessions_user_idx    on public.app_sessions(user_id, started_at desc);
create index if not exists app_sessions_started_idx on public.app_sessions(started_at);

create table if not exists public.projects (
  user_id    uuid not null references auth.users(id) on delete cascade default auth.uid(),
  id         text not null,
  name       text,
  updated_at timestamptz not null default now(),
  bytes      integer default 0,
  objects    integer default 0,
  w          integer,
  h          integer,
  thumb      text,
  primary key (user_id, id)
);

create table if not exists public.admin_assets (
  name text primary key,
  body text not null
);

-- ---------- 2. ROW LEVEL SECURITY (each user sees only their own data) --
alter table public.profiles     enable row level security;
alter table public.app_sessions enable row level security;
alter table public.projects     enable row level security;
alter table public.admin_assets enable row level security;   -- no policy = nobody can read it directly

drop policy if exists "profiles read own"   on public.profiles;
create policy "profiles read own" on public.profiles for select to authenticated using (id = auth.uid());

drop policy if exists "sessions read own"   on public.app_sessions;
drop policy if exists "sessions insert own" on public.app_sessions;
drop policy if exists "sessions update own" on public.app_sessions;
create policy "sessions read own"   on public.app_sessions for select to authenticated using (user_id = auth.uid());
create policy "sessions insert own" on public.app_sessions for insert to authenticated with check (user_id = auth.uid());
create policy "sessions update own" on public.app_sessions for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "projects read own"   on public.projects;
drop policy if exists "projects insert own" on public.projects;
drop policy if exists "projects update own" on public.projects;
drop policy if exists "projects delete own" on public.projects;
create policy "projects read own"   on public.projects for select to authenticated using (user_id = auth.uid());
create policy "projects insert own" on public.projects for insert to authenticated with check (user_id = auth.uid());
create policy "projects update own" on public.projects for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "projects delete own" on public.projects for delete to authenticated using (user_id = auth.uid());

revoke all on public.profiles, public.app_sessions, public.projects, public.admin_assets from anon;
grant select on public.profiles to authenticated;
grant select, insert, update on public.app_sessions to authenticated;
grant select, insert, update, delete on public.projects to authenticated;

-- ---------- 3. AUTO-CREATE A PROFILE WHEN SOMEONE SIGNS UP -------------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public, auth as $$
begin
  insert into public.profiles (id, email, created_at, terms_version, terms_accepted_at)
  values (
    new.id, new.email, coalesce(new.created_at, now()),
    new.raw_user_meta_data ->> 'terms_version',
    nullif(new.raw_user_meta_data ->> 'terms_accepted_at', '')::timestamptz
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- people who already signed up before running this script
insert into public.profiles (id, email, created_at, terms_version, terms_accepted_at)
select u.id, u.email, u.created_at, u.raw_user_meta_data ->> 'terms_version',
       nullif(u.raw_user_meta_data ->> 'terms_accepted_at', '')::timestamptz
from auth.users u
on conflict (id) do nothing;

-- ---------- 4. USAGE TRACKING (visits + time used) ---------------------
create or replace function public.track_session_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.profiles
     set visit_count   = visit_count + 1,
         total_seconds = total_seconds + greatest(new.duration_seconds, 0),
         last_seen_at  = greatest(coalesce(last_seen_at, new.last_ping), new.last_ping)
   where id = new.user_id;
  return new;
end $$;

create or replace function public.track_session_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.profiles
     set total_seconds = total_seconds + greatest(new.duration_seconds - old.duration_seconds, 0),
         last_seen_at  = greatest(coalesce(last_seen_at, new.last_ping), new.last_ping)
   where id = new.user_id;
  return new;
end $$;

drop trigger if exists app_sessions_ai on public.app_sessions;
drop trigger if exists app_sessions_au on public.app_sessions;
create trigger app_sessions_ai after insert on public.app_sessions for each row execute function public.track_session_insert();
create trigger app_sessions_au after update on public.app_sessions for each row execute function public.track_session_update();

-- ---------- 5. FILE STORAGE (saved projects, private per user) --------
insert into storage.buckets (id, name, public, file_size_limit)
values ('projects', 'projects', false, 52428800)
on conflict (id) do update set public = false, file_size_limit = 52428800;

drop policy if exists "vs projects read own"   on storage.objects;
drop policy if exists "vs projects insert own" on storage.objects;
drop policy if exists "vs projects update own" on storage.objects;
drop policy if exists "vs projects delete own" on storage.objects;
create policy "vs projects read own"   on storage.objects for select to authenticated
  using (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "vs projects insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "vs projects update own" on storage.objects for update to authenticated
  using (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "vs projects delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'projects' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------- 6. ADMIN (only kakayowika0@gmail.com) ---------------------
-- The admin must have a CONFIRMED account with this exact email.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public, auth as $$
  select exists (
    select 1 from auth.users u
    where u.id = auth.uid()
      and lower(u.email) = 'kakayowika0@gmail.com'
      and u.email_confirmed_at is not null
  );
$$;

-- Returns the hidden admin-panel code to the admin, and NULL to everybody else.
create or replace function public.get_app_extras()
returns text language sql stable security definer set search_path = public as $$
  select case when public.is_admin() then (select body from public.admin_assets where name = 'panel') else null end;
$$;

create or replace function public.admin_overview()
returns jsonb language plpgsql stable security definer set search_path = public, auth as $$
declare r jsonb;
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  select jsonb_build_object(
    'total_users',     (select count(*) from public.profiles),
    'confirmed_users', (select count(*) from auth.users where email_confirmed_at is not null),
    'new_24h',  (select count(*) from public.profiles where created_at > now() - interval '1 day'),
    'new_7d',   (select count(*) from public.profiles where created_at > now() - interval '7 days'),
    'new_30d',  (select count(*) from public.profiles where created_at > now() - interval '30 days'),
    'active_24h', (select count(*) from public.profiles where last_seen_at > now() - interval '1 day'),
    'active_7d',  (select count(*) from public.profiles where last_seen_at > now() - interval '7 days'),
    'active_30d', (select count(*) from public.profiles where last_seen_at > now() - interval '30 days'),
    'inactive_7d',  (select count(*) from public.profiles where last_seen_at is null or last_seen_at < now() - interval '7 days'),
    'inactive_30d', (select count(*) from public.profiles where last_seen_at is null or last_seen_at < now() - interval '30 days'),
    'returning_users', (select count(*) from public.profiles where visit_count >= 2),
    'total_seconds', (select coalesce(sum(total_seconds),0) from public.profiles),
    'avg_seconds_per_user', (select coalesce(round(avg(total_seconds)),0) from public.profiles),
    'total_sessions', (select count(*) from public.app_sessions),
    'avg_session_seconds', (select coalesce(round(avg(duration_seconds)),0) from public.app_sessions),
    'total_projects', (select count(*) from public.projects),
    'total_bytes', (select coalesce(sum(bytes),0) from public.projects),
    'daily', (
      select coalesce(jsonb_agg(jsonb_build_object('day', to_char(d.day,'YYYY-MM-DD'),
               'signups', (select count(*) from public.profiles p where p.created_at::date = d.day),
               'active',  (select count(distinct s.user_id) from public.app_sessions s where s.started_at::date = d.day)
             ) order by d.day), '[]'::jsonb)
      from (select generate_series(current_date - 13, current_date, interval '1 day')::date as day) d
    )
  ) into r;
  return r;
end $$;

create or replace function public.admin_users()
returns table (id uuid, email text, created_at timestamptz, last_seen_at timestamptz, visit_count integer,
               total_seconds bigint, projects bigint, bytes bigint, terms_version text,
               terms_accepted_at timestamptz, confirmed boolean)
language plpgsql stable security definer set search_path = public, auth as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  return query
    select p.id, p.email, p.created_at, p.last_seen_at, p.visit_count, p.total_seconds,
           (select count(*) from public.projects j where j.user_id = p.id),
           (select coalesce(sum(j.bytes),0)::bigint from public.projects j where j.user_id = p.id),
           p.terms_version, p.terms_accepted_at,
           (u.email_confirmed_at is not null)
    from public.profiles p
    left join auth.users u on u.id = p.id
    order by p.created_at desc;
end $$;

create or replace function public.admin_user_sessions(p_user uuid, p_limit integer default 50)
returns table (started_at timestamptz, last_ping timestamptz, duration_seconds integer, device text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  return query
    select s.started_at, s.last_ping, s.duration_seconds, s.device
    from public.app_sessions s where s.user_id = p_user
    order by s.started_at desc limit least(coalesce(p_limit,50), 200);
end $$;

revoke all on function public.is_admin(), public.get_app_extras(), public.admin_overview(),
  public.admin_users(), public.admin_user_sessions(uuid, integer) from public, anon;
grant execute on function public.is_admin(), public.get_app_extras(), public.admin_overview(),
  public.admin_users(), public.admin_user_sessions(uuid, integer) to authenticated;

-- ---------- 7. HIDDEN ADMIN PANEL (only the admin can ever download this) --
insert into public.admin_assets (name, body) values ('panel', $vsadmin$
(function (VSA, sb) {
  'use strict';
  var esc = VSA.esc;
  var BR = 'linear-gradient(135deg,#f14a11,#db1924 38%,#bb339c 72%,#884bcd)';
  var DAY = 86400000;
  var css = '' +
    '#vsx{position:fixed;inset:0;z-index:2147483100;background:#0b0718;color:#f3effa;font-family:"DM Sans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;display:flex;flex-direction:column;overscroll-behavior:contain}' +
    '#vsx *{box-sizing:border-box}' +
    '#vsx .vsx-hd{display:flex;align-items:center;gap:10px;padding:calc(12px + env(safe-area-inset-top,0px)) 14px 10px;border-bottom:1px solid rgba(255,255,255,.08)}' +
    '#vsx .vsx-hd h2{margin:0 auto 0 0;font-size:18px;font-weight:700;flex:0 0 auto;background:' + BR + ';-webkit-background-clip:text;background-clip:text;color:transparent}' +
    '#vsx .vsx-ib{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);color:#fff;border-radius:12px;height:36px;min-width:36px;padding:0 12px;font:inherit;font-size:13px;cursor:pointer}' +
    '#vsx .vsx-ib:active{transform:scale(.96)}' +
    '#vsx .vsx-tabs{display:flex;gap:6px;padding:10px 14px 0}' +
    '#vsx .vsx-tab{flex:1;height:38px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:transparent;color:#cfc6e6;font:inherit;font-weight:600;font-size:14px;cursor:pointer}' +
    '#vsx .vsx-tab.vsx-on{background:' + BR + ';color:#fff;border-color:transparent}' +
    '#vsx .vsx-bd{flex:1;overflow:auto;padding:14px 14px calc(24px + env(safe-area-inset-bottom,0px));-webkit-overflow-scrolling:touch}' +
    '#vsx .vsx-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}' +
    '@media(min-width:760px){#vsx .vsx-grid{grid-template-columns:repeat(4,1fr)}}' +
    '#vsx .vsx-card{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:12px 14px}' +
    '#vsx .vsx-card .vsx-k{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:#a99fc4}' +
    '#vsx .vsx-card .vsx-v{font-size:24px;font-weight:700;margin-top:4px}' +
    '#vsx .vsx-card .vsx-s{font-size:12px;color:#a99fc4;margin-top:2px}' +
    '#vsx h3{font-size:14px;margin:18px 0 8px;color:#e8e1f7}' +
    '#vsx .vsx-chart{display:flex;align-items:flex-end;gap:5px;height:130px;padding:8px 6px 0}' +
    '#vsx .vsx-col{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;min-width:0}' +
    '#vsx .vsx-pair{display:flex;align-items:flex-end;gap:2px;height:100px;width:100%;justify-content:center}' +
    '#vsx .vsx-bar{width:42%;border-radius:4px 4px 0 0;min-height:2px}' +
    '#vsx .vsx-lbl{font-size:9px;color:#a99fc4;margin-top:4px;white-space:nowrap}' +
    '#vsx .vsx-lg{display:flex;gap:14px;font-size:12px;color:#cfc6e6;margin-top:8px}' +
    '#vsx .vsx-lg i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}' +
    '#vsx input.vsx-q{width:100%;height:42px;border-radius:12px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.07);color:#fff;padding:0 14px;font:inherit;font-size:14px;outline:none}' +
    '#vsx .vsx-chips{display:flex;gap:6px;overflow-x:auto;padding:10px 0}' +
    '#vsx .vsx-chip{flex:0 0 auto;border-radius:999px;border:1px solid rgba(255,255,255,.15);background:transparent;color:#cfc6e6;padding:6px 12px;font:inherit;font-size:12px;cursor:pointer}' +
    '#vsx .vsx-chip.vsx-on{background:' + BR + ';color:#fff;border-color:transparent}' +
    '#vsx .vsx-row{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:14px;padding:11px 13px;margin-bottom:8px;cursor:pointer}' +
    '#vsx .vsx-row .vsx-em{font-weight:600;font-size:14px;word-break:break-all}' +
    '#vsx .vsx-row .vsx-mt{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12px;color:#a99fc4;margin-top:5px}' +
    '#vsx .vsx-badge{display:inline-block;font-size:10px;font-weight:700;padding:2px 8px;border-radius:999px;margin-left:8px;vertical-align:1px}' +
    '#vsx .vsx-b-on{background:rgba(52,211,153,.18);color:#6ee7b7}#vsx .vsx-b-act{background:rgba(96,165,250,.18);color:#93c5fd}' +
    '#vsx .vsx-b-in{background:rgba(251,191,36,.18);color:#fcd34d}#vsx .vsx-b-dm{background:rgba(248,113,113,.18);color:#fca5a5}' +
    '#vsx .vsx-det{position:absolute;inset:0;background:#0b0718;display:flex;flex-direction:column;z-index:2}' +
    '#vsx table{width:100%;border-collapse:collapse;font-size:12px}#vsx td,#vsx th{padding:7px 6px;border-bottom:1px solid rgba(255,255,255,.07);text-align:left}' +
    '#vsx th{color:#a99fc4;font-weight:600}#vsx .vsx-empty{color:#a99fc4;text-align:center;padding:30px 10px;font-size:13px}';

  function fmtDur(s) {
    s = Math.max(0, Math.round(+s || 0));
    if (s < 60) return s + 's';
    var m = Math.floor(s / 60);
    if (m < 60) return m + ' min';
    var h = Math.floor(m / 60);
    return h + 'h ' + (m % 60) + 'm';
  }
  function fmtDate(d) {
    if (!d) return 'Never';
    var x = new Date(d);
    return x.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' }) + ' ' + x.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  }
  function ago(d) {
    if (!d) return 'never';
    var s = (Date.now() - new Date(d).getTime()) / 1000;
    if (s < 90) return 'just now';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago';
    return Math.round(s / 86400) + ' d ago';
  }
  function fmtBytes(b) {
    b = +b || 0;
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
    return (b / 1048576).toFixed(1) + ' MB';
  }
  function status(u) {
    var t = u.last_seen_at ? new Date(u.last_seen_at).getTime() : 0;
    var age = Date.now() - t;
    if (!t) return ['dm', 'Never opened'];
    if (age < DAY) return ['on', 'Active today'];
    if (age < 7 * DAY) return ['act', 'Active'];
    if (age < 30 * DAY) return ['in', 'Inactive 7d+'];
    return ['dm', 'Inactive 30d+'];
  }

  var root, state = { tab: 'overview', filter: 'all', q: '', ov: null, users: [] };

  function open() {
    if (document.getElementById('vsx')) return;
    var st = document.createElement('style');
    st.id = 'vsx-style';
    st.textContent = css;
    document.head.appendChild(st);
    root = document.createElement('div');
    root.id = 'vsx';
    root.innerHTML = '<div class="vsx-hd"><h2>Admin</h2><button class="vsx-ib" id="vsx-csv">CSV</button><button class="vsx-ib" id="vsx-rf">Refresh</button><button class="vsx-ib" id="vsx-x" aria-label="Close">✕</button></div>' +
      '<div class="vsx-tabs"><button class="vsx-tab vsx-on" data-t="overview">Overview</button><button class="vsx-tab" data-t="users">Users</button></div>' +
      '<div class="vsx-bd" id="vsx-bd"><div class="vsx-empty">Loading…</div></div>';
    document.body.appendChild(root);
    root.querySelector('#vsx-x').onclick = close;
    root.querySelector('#vsx-rf').onclick = load;
    root.querySelector('#vsx-csv').onclick = exportCsv;
    root.querySelectorAll('.vsx-tab').forEach(function (b) {
      b.onclick = function () {
        state.tab = b.dataset.t;
        root.querySelectorAll('.vsx-tab').forEach(function (x) { x.classList.toggle('vsx-on', x === b); });
        render();
      };
    });
    load();
  }
  function close() {
    if (root) root.remove();
    var s = document.getElementById('vsx-style');
    if (s) s.remove();
    root = null;
  }

  async function load() {
    var bd = root && root.querySelector('#vsx-bd');
    if (bd) bd.innerHTML = '<div class="vsx-empty">Loading…</div>';
    if (!navigator.onLine) { if (bd) bd.innerHTML = '<div class="vsx-empty">You are offline. The admin panel needs internet.</div>'; return; }
    var a = await sb.rpc('admin_overview');
    var b = await sb.rpc('admin_users');
    if (a.error || b.error) {
      if (bd) bd.innerHTML = '<div class="vsx-empty">Could not load data.<br>' + esc((a.error || b.error).message) + '<br><br>Check that you ran the full SQL setup.</div>';
      return;
    }
    state.ov = a.data || {};
    state.users = b.data || [];
    render();
  }

  function card(k, v, s) {
    return '<div class="vsx-card"><div class="vsx-k">' + k + '</div><div class="vsx-v">' + v + '</div>' + (s ? '<div class="vsx-s">' + s + '</div>' : '') + '</div>';
  }

  function render() {
    var bd = root && root.querySelector('#vsx-bd');
    if (!bd || !state.ov) return;
    if (state.tab === 'overview') renderOverview(bd); else renderUsers(bd);
  }

  function renderOverview(bd) {
    var o = state.ov;
    var daily = o.daily || [];
    var max = 1;
    daily.forEach(function (d) { max = Math.max(max, d.signups, d.active); });
    var bars = daily.map(function (d) {
      var dt = new Date(d.day + 'T00:00:00');
      return '<div class="vsx-col"><div class="vsx-pair"><div class="vsx-bar" title="New" style="height:' + Math.round(d.signups / max * 100) + '%;background:#f14a11"></div>' +
        '<div class="vsx-bar" title="Active" style="height:' + Math.round(d.active / max * 100) + '%;background:#884bcd"></div></div><div class="vsx-lbl">' + dt.getDate() + '/' + (dt.getMonth() + 1) + '</div></div>';
    }).join('');
    var inactive = state.users.filter(function (u) { return !u.last_seen_at || Date.now() - new Date(u.last_seen_at).getTime() > 7 * DAY; })
      .sort(function (a, b) { return new Date(a.last_seen_at || 0) - new Date(b.last_seen_at || 0); }).slice(0, 15);
    var top = state.users.slice().sort(function (a, b) { return (b.total_seconds || 0) - (a.total_seconds || 0); }).slice(0, 10);
    bd.innerHTML =
      '<div class="vsx-grid">' +
      card('Total users', o.total_users, 'Confirmed: ' + o.confirmed_users) +
      card('New today', o.new_24h, o.new_7d + ' in 7 days · ' + o.new_30d + ' in 30 days') +
      card('Active (24h)', o.active_24h, o.active_7d + ' in 7 days · ' + o.active_30d + ' in 30 days') +
      card('Not returned', o.inactive_7d, o.inactive_30d + ' gone for 30+ days') +
      card('Total time in app', fmtDur(o.total_seconds), 'Avg per user: ' + fmtDur(o.avg_seconds_per_user)) +
      card('Sessions', o.total_sessions, 'Avg length: ' + fmtDur(o.avg_session_seconds)) +
      card('Cloud projects', o.total_projects, 'Storage: ' + fmtBytes(o.total_bytes)) +
      card('Returning users', o.returning_users, 'Opened the app 2+ times') +
      '</div>' +
      '<h3>Last 14 days</h3><div class="vsx-card"><div class="vsx-chart">' + bars + '</div><div class="vsx-lg"><span><i style="background:#f14a11"></i>New users</span><span><i style="background:#884bcd"></i>Active users</span></div></div>' +
      '<h3>Most time in the app</h3>' + (top.length ? top.map(rowHtml).join('') : '<div class="vsx-empty">No data yet</div>') +
      '<h3>Not visited in 7+ days</h3>' + (inactive.length ? inactive.map(rowHtml).join('') : '<div class="vsx-empty">Everyone has been active this week 🎉</div>');
    bindRows(bd);
  }

  function rowHtml(u) {
    var s = status(u);
    return '<div class="vsx-row" data-id="' + esc(u.id) + '"><div class="vsx-em">' + esc(u.email) + '<span class="vsx-badge vsx-b-' + s[0] + '">' + s[1] + '</span></div>' +
      '<div class="vsx-mt"><span>Joined ' + fmtDate(u.created_at) + '</span><span>Last seen ' + ago(u.last_seen_at) + '</span><span>' + (u.visit_count || 0) + ' visits</span><span>' + fmtDur(u.total_seconds) + ' used</span><span>' + (u.projects || 0) + ' projects</span></div></div>';
  }
  function bindRows(bd) {
    bd.querySelectorAll('.vsx-row').forEach(function (r) { r.onclick = function () { detail(r.dataset.id); }; });
  }

  function filtered() {
    var q = state.q.trim().toLowerCase();
    var now = Date.now();
    return state.users.filter(function (u) {
      if (q && String(u.email).toLowerCase().indexOf(q) < 0) return false;
      var t = u.last_seen_at ? new Date(u.last_seen_at).getTime() : 0;
      var c = new Date(u.created_at).getTime();
      switch (state.filter) {
        case 'new7': return now - c < 7 * DAY;
        case 'act7': return t && now - t < 7 * DAY;
        case 'in7': return !t || now - t >= 7 * DAY;
        case 'in30': return !t || now - t >= 30 * DAY;
        default: return true;
      }
    });
  }

  function renderUsers(bd) {
    var chips = [['all', 'All'], ['new7', 'New (7d)'], ['act7', 'Active (7d)'], ['in7', 'Not back 7d+'], ['in30', 'Not back 30d+']];
    var list = filtered();
    bd.innerHTML = '<input class="vsx-q" id="vsx-q" placeholder="Search email…" value="' + esc(state.q) + '">' +
      '<div class="vsx-chips">' + chips.map(function (c) { return '<button class="vsx-chip' + (state.filter === c[0] ? ' vsx-on' : '') + '" data-f="' + c[0] + '">' + c[1] + '</button>'; }).join('') + '</div>' +
      '<div style="font-size:12px;color:#a99fc4;margin-bottom:8px">' + list.length + ' of ' + state.users.length + ' users</div>' +
      '<div id="vsx-list">' + (list.length ? list.map(rowHtml).join('') : '<div class="vsx-empty">No users match</div>') + '</div>';
    var qi = bd.querySelector('#vsx-q');
    qi.oninput = function () {
      state.q = qi.value;
      var l = filtered();
      bd.querySelector('#vsx-list').innerHTML = l.length ? l.map(rowHtml).join('') : '<div class="vsx-empty">No users match</div>';
      bindRows(bd);
    };
    bd.querySelectorAll('.vsx-chip').forEach(function (c) { c.onclick = function () { state.filter = c.dataset.f; renderUsers(bd); }; });
    bindRows(bd);
  }

  async function detail(id) {
    var u = state.users.find(function (x) { return x.id === id; });
    if (!u) return;
    var s = status(u);
    var d = document.createElement('div');
    d.className = 'det';
    d.innerHTML = '<div class="vsx-hd"><h2>User</h2><button class="vsx-ib" id="vsx-dx">✕</button></div><div class="vsx-bd"><div class="vsx-empty">Loading…</div></div>';
    root.appendChild(d);
    d.querySelector('#vsx-dx').onclick = function () { d.remove(); };
    var r = await sb.rpc('admin_user_sessions', { p_user: id, p_limit: 60 });
    var rows = (r.data || []).map(function (x) {
      return '<tr><td>' + fmtDate(x.started_at) + '</td><td>' + fmtDur(x.duration_seconds) + '</td><td>' + esc(x.device || '') + '</td></tr>';
    }).join('');
    d.querySelector('.vsx-bd').innerHTML =
      '<div class="vsx-card"><div class="vsx-em" style="font-weight:700;word-break:break-all">' + esc(u.email) + '<span class="vsx-badge vsx-b-' + s[0] + '">' + s[1] + '</span></div></div>' +
      '<div class="vsx-grid" style="margin-top:10px">' +
      card('Joined', fmtDate(u.created_at).split(' ').slice(0, 3).join(' '), 'Email confirmed: ' + (u.confirmed ? 'yes' : 'no')) +
      card('Last seen', ago(u.last_seen_at), fmtDate(u.last_seen_at)) +
      card('Visits', u.visit_count || 0, 'Avg ' + fmtDur((u.total_seconds || 0) / Math.max(1, u.visit_count || 0)) + ' each') +
      card('Total time', fmtDur(u.total_seconds), '') +
      card('Cloud projects', u.projects || 0, fmtBytes(u.bytes)) +
      card('Accepted terms', u.terms_version ? 'v' + esc(u.terms_version) : '—', u.terms_accepted_at ? fmtDate(u.terms_accepted_at) : '') +
      '</div><h3>Recent sessions</h3>' +
      (rows ? '<div class="vsx-card" style="padding:4px 8px;overflow:auto"><table><tr><th>Started</th><th>Time used</th><th>Device</th></tr>' + rows + '</table></div>' : '<div class="vsx-empty">No sessions recorded yet</div>');
  }

  function exportCsv() {
    var head = ['email', 'joined', 'last_seen', 'visits', 'total_minutes', 'projects', 'storage_bytes', 'terms_version', 'terms_accepted_at', 'status'];
    var lines = [head.join(',')];
    state.users.forEach(function (u) {
      var v = [u.email, u.created_at, u.last_seen_at || '', u.visit_count || 0, Math.round((u.total_seconds || 0) / 60), u.projects || 0, u.bytes || 0, u.terms_version || '', u.terms_accepted_at || '', status(u)[1]];
      lines.push(v.map(function (x) { return '"' + String(x).replace(/"/g, '""') + '"'; }).join(','));
    });
    var blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'vectorstudio-users-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1500);
  }

  VSA.addMenuItem('Admin panel', 'fa-solid fa-chart-line', open);
})(VSA, sb);

$vsadmin$)
on conflict (name) do update set body = excluded.body;

-- Done. You should see "Success. No rows returned".
